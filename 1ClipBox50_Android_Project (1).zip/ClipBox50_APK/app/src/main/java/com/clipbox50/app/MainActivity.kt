package com.clipbox50.app

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private val OVERLAY_PERMISSION_REQ_CODE = 1234

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.databaseEnabled = true

        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()

        // Expose native Android interface to Web Javascript
        webView.addJavascriptInterface(WebAppInterface(this), "AndroidBridge")

        // Load bundled asset or online app
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    inner class WebAppInterface(private val context: Context) {

        @JavascriptInterface
        fun copyToClipboard(text: String, label: String) {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText(label, text)
            clipboard.setPrimaryClip(clip)
            Toast.makeText(context, "Klip disalin: $label", Toast.LENGTH_SHORT).show()
        }

        @JavascriptInterface
        fun startFloatingBubble() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + context.packageName)
                )
                startActivityForResult(intent, OVERLAY_PERMISSION_REQ_CODE)
            } else {
                val serviceIntent = Intent(context, FloatingBubbleService::class.java)
                context.startService(serviceIntent)
                Toast.makeText(context, "Gelembung ClipBox 50 diaktifkan!", Toast.LENGTH_SHORT).show()
            }
        }

        @JavascriptInterface
        fun openKeyboardSettings() {
            val intent = Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)
            context.startActivity(intent)
        }
    }
}
