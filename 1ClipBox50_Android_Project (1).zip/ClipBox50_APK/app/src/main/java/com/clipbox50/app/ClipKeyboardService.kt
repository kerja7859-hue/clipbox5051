package com.clipbox50.app

import android.inputmethodservice.InputMethodService
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.GridLayout
import android.widget.Toast

class ClipKeyboardService : InputMethodService() {

    override fun onCreateInputView(): View {
        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.keyboard_view, null)

        val grid = view.findViewById<GridLayout>(R.id.keyboardGrid)

        // Read stored clips from SharedPreferences or defaults
        val prefs = getSharedPreferences("clipbox50_prefs", MODE_PRIVATE)
        
        for (i in 1..50) {
            val clipTitle = prefs.getString("slot_${i}_title", "Klip #$i") ?: "Klip #$i"
            val clipText = prefs.getString("slot_${i}_text", "Teks klip #$i") ?: ""

            val btn = Button(this).apply {
                text = clipTitle
                textSize = 12f
                setPadding(12, 8, 12, 8)
                setOnClickListener {
                    val inputConnection = currentInputConnection
                    if (inputConnection != null && clipText.isNotEmpty()) {
                        inputConnection.commitText(clipText, 1)
                    } else {
                        Toast.makeText(this@ClipKeyboardService, "Klip #$i masih kosong", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            grid.addView(btn)
        }

        return view
    }
}
