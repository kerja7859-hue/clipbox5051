# ClipBox 50 — Android APK Project

Proyek ini adalah source code Android lengkap untuk aplikasi **ClipBox 50** (Clipboard Manager 50 Kotak).

### Cara Menghasilkan File .APK:

#### Cara 1: Bangun Otomatis Lewat GitHub Actions (Paling Mudah, Tanpa Install Apapun)
1. Buat repository baru di GitHub akun Anda.
2. Unggah (upload) seluruh isi folder ini ke repository GitHub.
3. Buka tab **Actions** di GitHub, workflow "Build Android APK" akan otomatis berjalan.
4. Setelah selesai (±1-2 menit), unduh file `ClipBox50-debug-apk.zip` lalu ekstrak file `app-debug.apk` dan install ke HP Android Anda!

#### Cara 2: Bangun Lewat Android Studio di PC / Laptop
1. Buka software **Android Studio**.
2. Pilih **Open**, arahkan ke folder `ClipBox50_APK`.
3. Tunggu proses Gradle Sync selesai.
4. Klik menu **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**.
5. Setelah selesai, klik tautan "locate" untuk mengambil file `app-debug.apk`.

#### Cara 3: Bangun Langsung di HP Android Menggunakan Termux
```bash
pkg update && pkg install openjdk-17 gradle -y
cd ClipBox50_APK
gradle assembleDebug
# File APK akan berada di: app/build/outputs/apk/debug/app-debug.apk
```
